%% Humanoid Robot
% This example has been imported from a URDF file using the smimport command. 
% The URDF file "Humanoid.urdf" and the STEP files that visualize the robot
% parts were used to create this example. Motion actuation of the joints was 
% manually added to the imported model to make the robot perform interesting 
% movements.
%
% Copyright 2008-2023 The MathWorks, Inc.

open_system('ImportedURDF');
%%
close_system('ImportedURDF');